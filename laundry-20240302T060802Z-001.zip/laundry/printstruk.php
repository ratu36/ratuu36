<?php
session_start();
if (isset($_SESSION['id'])) {
    include "./include/koneksi.php";

    if (isset($_GET['No_Order'])) {
        $sql = mysqli_query($conn, "SELECT No_Order FROM transaksi  ORDER BY No_Order Desc LIMIT 1");
        while ($hasil = mysqli_fetch_array($sql)){
          $no = $hasil['No_Order'];
        }
    } else {
        // header("location:index.php");
    }
} else {
    // header("location:login/index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laundry - Struk</title>
    <style>
        body {
            background-color: #FFB6C1;
        }
    </style>
    <script>
        function printStruk() {
            window.print();
        }
    </script>
</head>
<body>
<div class="container">
    <h3>Struk Transaksi Laundry</h3>
    <hr>
    <div>
    <table class="table">
    <td><?php echo $hasil['No_Order']; ?></td>
      <td><?php echo $hasil['Nama']; ?></td>
      <td><?php echo $hasil['Tgl_Terima']; ?></td>
      <td><?php echo $hasil['Tgl_Ambil']; ?></td>
      <td><?php echo $hasil['total_berat']; ?></td>
      <td><?php echo $hasil['diskon']; ?></td>
      <td><?php echo $hasil['Total_Bayar']; ?></td>
        <hr>
        <p>Terima kasih atas kepercayaan Anda menggunakan layanan kami!</p>
        <button onclick="printStruk()">Cetak Struk</button>
    </table>
    </div>
</div>
</body>
</html>