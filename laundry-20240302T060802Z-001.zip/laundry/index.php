<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>LAUNDRY</title>
    

    <link rel="stylesheet" href="home/css/landio.css">
  </head>

  <body>

   


    <header class="jumbotron bg-inverse text-xs-center center-vertically" role="banner">
      <div class="container">
        <h1 class="display-4">Laundry  </h1>
        <h2 class="m-b-3">Bersih, Wangi, dan Ekonomis</h2>
        <a class="btn btn-secondary-outline m-b-1" href="login/index.php" role="button">Masuk</a>
      </div>
    </header>





    
  </body>
</html>
